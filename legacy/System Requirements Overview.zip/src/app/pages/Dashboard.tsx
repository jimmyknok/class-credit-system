import React from 'react';
import { useNavigate } from 'react-router';
import { useApp } from '../context/AppContext';
import { Users, Star, TrendingUp, Award, Plus, Shuffle, Timer, ArrowRight } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';

const COLORS = ['#6366f1', '#8b5cf6', '#a78bfa', '#c4b5fd', '#ddd6fe'];

export default function Dashboard() {
  const { students, groups, records, shopItems, getGroupById, getStudentById } = useApp();
  const navigate = useNavigate();

  const totalStudents = students.length;
  const avgPoints = totalStudents > 0 ? Math.round(students.reduce((s, st) => s + st.totalPoints, 0) / totalStudents) : 0;
  const maxPoints = students.reduce((m, s) => Math.max(m, s.totalPoints), 0);
  const topStudent = students.find(s => s.totalPoints === maxPoints);
  const recentRecords = [...records].sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, 6);

  const topStudents = [...students].sort((a, b) => b.totalPoints - a.totalPoints).slice(0, 8).map(s => ({
    name: s.name,
    points: s.totalPoints,
    group: getGroupById(s.groupId || '') || null,
  }));

  const groupStats = groups.map(g => {
    const members = students.filter(s => s.groupId === g.id);
    const total = members.reduce((s, m) => s + m.totalPoints, 0);
    return { name: g.name, points: total, color: g.color, count: members.length };
  }).sort((a, b) => b.points - a.points);

  const formatDate = (iso: string) => {
    const d = new Date(iso);
    return `${d.getMonth() + 1}/${d.getDate()} ${d.getHours()}:${String(d.getMinutes()).padStart(2, '0')}`;
  };

  const typeLabel = (type: string) => ({ earn: '加分', deduct: '扣分', redeem: '兑换' }[type] || type);
  const typeColor = (type: string) => ({ earn: 'text-emerald-600 bg-emerald-50', deduct: 'text-red-600 bg-red-50', redeem: 'text-purple-600 bg-purple-50' }[type] || '');
  const typeSign = (type: string, pts: number) => type === 'earn' ? `+${pts}` : `-${pts}`;

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-gray-900">总览</h1>
          <p className="text-sm text-gray-500 mt-0.5">班级积分数据一览</p>
        </div>
        <div className="flex gap-2">
          <button onClick={() => navigate('/points')} className="flex items-center gap-1.5 px-3 py-2 bg-indigo-600 text-white rounded-lg text-sm hover:bg-indigo-700 transition-colors">
            <Plus className="w-4 h-4" /> 积分操作
          </button>
          <button onClick={() => navigate('/tools')} className="flex items-center gap-1.5 px-3 py-2 bg-white text-gray-700 rounded-lg text-sm border border-gray-200 hover:bg-gray-50 transition-colors">
            <Shuffle className="w-4 h-4" /> 课堂工具
          </button>
        </div>
      </div>

      {/* Stats Row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: '学生总数', value: totalStudents, sub: `${groups.length} 个小组`, icon: Users, color: 'bg-blue-50 text-blue-600' },
          { label: '平均积分', value: avgPoints, sub: '历史累计', icon: Star, color: 'bg-indigo-50 text-indigo-600' },
          { label: '最高积分', value: maxPoints, sub: topStudent?.name || '-', icon: Award, color: 'bg-amber-50 text-amber-600' },
          { label: '总记录数', value: records.length, sub: `${shopItems.reduce((s, i) => s + i.sold, 0)} 次兑换`, icon: TrendingUp, color: 'bg-emerald-50 text-emerald-600' },
        ].map(stat => (
          <div key={stat.label} className="bg-white rounded-xl border border-gray-100 p-5 shadow-sm">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-xs text-gray-500 mb-1">{stat.label}</p>
                <p className="text-3xl font-semibold text-gray-900">{stat.value}</p>
                <p className="text-xs text-gray-400 mt-1">{stat.sub}</p>
              </div>
              <div className={`w-9 h-9 rounded-lg flex items-center justify-center ${stat.color}`}>
                <stat.icon className="w-4.5 h-4.5" />
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Top Students Chart */}
        <div className="lg:col-span-2 bg-white rounded-xl border border-gray-100 shadow-sm p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-gray-900">积分排行榜</h3>
            <button onClick={() => navigate('/students')} className="text-xs text-indigo-600 hover:text-indigo-700 flex items-center gap-1">
              查看全部 <ArrowRight className="w-3 h-3" />
            </button>
          </div>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={topStudents} layout="vertical" margin={{ left: 8, right: 20, top: 0, bottom: 0 }}>
              <XAxis type="number" tick={{ fontSize: 11, fill: '#9ca3af' }} axisLine={false} tickLine={false} />
              <YAxis type="category" dataKey="name" tick={{ fontSize: 12, fill: '#4b5563' }} axisLine={false} tickLine={false} width={40} />
              <Tooltip
                formatter={(val: number) => [`${val} 分`, '总积分']}
                contentStyle={{ border: 'none', boxShadow: '0 4px 24px rgba(0,0,0,0.1)', borderRadius: '8px', fontSize: 12 }}
              />
              <Bar dataKey="points" radius={[0, 4, 4, 0]} barSize={18}>
                {topStudents.map((_, i) => (
                  <Cell key={i} fill={COLORS[Math.min(i, COLORS.length - 1)]} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Group Ranking */}
        <div className="bg-white rounded-xl border border-gray-100 shadow-sm p-5">
          <h3 className="text-gray-900 mb-4">小组排行</h3>
          <div className="space-y-3">
            {groupStats.length === 0 && <p className="text-sm text-gray-400 text-center py-4">暂无小组数据</p>}
            {groupStats.map((g, i) => (
              <div key={g.name} className="flex items-center gap-3">
                <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-semibold text-white flex-shrink-0`}
                  style={{ backgroundColor: g.color }}>
                  {i + 1}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-sm text-gray-700 truncate">{g.name}</span>
                    <span className="text-sm font-medium text-gray-900">{g.points}</span>
                  </div>
                  <div className="h-1.5 bg-gray-100 rounded-full overflow-hidden">
                    <div className="h-full rounded-full transition-all" style={{ width: `${groupStats[0].points > 0 ? (g.points / groupStats[0].points) * 100 : 0}%`, backgroundColor: g.color }} />
                  </div>
                  <p className="text-xs text-gray-400 mt-0.5">{g.count} 名成员</p>
                </div>
              </div>
            ))}
          </div>
          <button onClick={() => navigate('/groups')} className="mt-4 w-full text-xs text-center text-indigo-600 hover:text-indigo-700">
            管理小组 <ArrowRight className="w-3 h-3 inline" />
          </button>
        </div>
      </div>

      {/* Recent Records */}
      <div className="bg-white rounded-xl border border-gray-100 shadow-sm p-5">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-gray-900">最新记录</h3>
          <button onClick={() => navigate('/records')} className="text-xs text-indigo-600 hover:text-indigo-700 flex items-center gap-1">
            查看全部 <ArrowRight className="w-3 h-3" />
          </button>
        </div>
        {recentRecords.length === 0 ? (
          <p className="text-sm text-gray-400 text-center py-6">暂无积分记录</p>
        ) : (
          <div className="divide-y divide-gray-50">
            {recentRecords.map(rec => {
              const student = getStudentById(rec.studentId);
              return (
                <div key={rec.id} className="flex items-center gap-3 py-3">
                  <div className="w-8 h-8 rounded-full bg-indigo-100 flex items-center justify-center text-sm font-medium text-indigo-700 flex-shrink-0">
                    {student?.name.slice(0, 1) || '?'}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-gray-800">{student?.name || '未知学生'} · {rec.reason}</p>
                    <p className="text-xs text-gray-400">{formatDate(rec.createdAt)}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${typeColor(rec.type)}`}>{typeLabel(rec.type)}</span>
                    <span className={`text-sm font-semibold ${rec.type === 'earn' ? 'text-emerald-600' : 'text-red-600'}`}>
                      {typeSign(rec.type, rec.points)}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { label: '加减积分', icon: Star, to: '/points', color: 'bg-indigo-600 hover:bg-indigo-700 text-white' },
          { label: '随机点名', icon: Shuffle, to: '/tools', color: 'bg-purple-600 hover:bg-purple-700 text-white' },
          { label: '课堂计时', icon: Timer, to: '/tools', color: 'bg-amber-500 hover:bg-amber-600 text-white' },
          { label: '积分商店', icon: Award, to: '/shop', color: 'bg-emerald-600 hover:bg-emerald-700 text-white' },
        ].map(a => (
          <button key={a.label} onClick={() => navigate(a.to)}
            className={`flex items-center justify-center gap-2 px-4 py-3 rounded-xl text-sm transition-colors ${a.color}`}>
            <a.icon className="w-4 h-4" /> {a.label}
          </button>
        ))}
      </div>
    </div>
  );
}