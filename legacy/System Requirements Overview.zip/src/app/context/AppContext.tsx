import React, { createContext, useContext, useState, useEffect } from 'react';

export type RecordType = 'earn' | 'deduct' | 'redeem';

export interface Student {
  id: string;
  name: string;
  groupId: string | null;
  totalPoints: number;
  availablePoints: number;
  createdAt: string;
}

export interface Group {
  id: string;
  name: string;
  color: string;
}

export interface PointRule {
  id: string;
  name: string;
  points: number;
  icon: string;
}

export interface PointRecord {
  id: string;
  studentId: string;
  type: RecordType;
  points: number;
  reason: string;
  ruleId?: string;
  shopItemId?: string;
  createdAt: string;
}

export interface ShopItem {
  id: string;
  name: string;
  requiredPoints: number;
  stock: number;
  description: string;
  sold: number;
}

export interface AppState {
  students: Student[];
  groups: Group[];
  rules: PointRule[];
  records: PointRecord[];
  shopItems: ShopItem[];
}

const uid = () => Math.random().toString(36).slice(2, 9) + Date.now().toString(36);

const INITIAL_GROUPS: Group[] = [
  { id: 'g1', name: '四大天王', color: '#6366f1' },
  { id: 'g2', name: '新人组', color: '#10b981' },
  { id: 'g3', name: '精英组', color: '#f59e0b' },
];

const INITIAL_STUDENTS: Student[] = [
  { id: 's1', name: '张伟', groupId: 'g1', totalPoints: 120, availablePoints: 95, createdAt: '2024-09-01T08:00:00Z' },
  { id: 's2', name: '李娜', groupId: 'g1', totalPoints: 145, availablePoints: 120, createdAt: '2024-09-01T08:01:00Z' },
  { id: 's3', name: '王明', groupId: 'g2', totalPoints: 80, availablePoints: 70, createdAt: '2024-09-01T08:02:00Z' },
  { id: 's4', name: '陈芳', groupId: 'g2', totalPoints: 95, availablePoints: 85, createdAt: '2024-09-01T08:03:00Z' },
  { id: 's5', name: '刘洋', groupId: 'g1', totalPoints: 110, availablePoints: 90, createdAt: '2024-09-01T08:04:00Z' },
  { id: 's6', name: '赵璐', groupId: 'g3', totalPoints: 160, availablePoints: 140, createdAt: '2024-09-01T08:05:00Z' },
  { id: 's7', name: '孙浩', groupId: 'g3', totalPoints: 75, availablePoints: 65, createdAt: '2024-09-01T08:06:00Z' },
  { id: 's8', name: '周婷', groupId: 'g2', totalPoints: 130, availablePoints: 110, createdAt: '2024-09-01T08:07:00Z' },
  { id: 's9', name: '吴刚', groupId: null, totalPoints: 55, availablePoints: 45, createdAt: '2024-09-01T08:08:00Z' },
  { id: 's10', name: '郑梅', groupId: 'g3', totalPoints: 140, availablePoints: 125, createdAt: '2024-09-01T08:09:00Z' },
];

const INITIAL_RULES: PointRule[] = [
  { id: 'r1', name: '全勤', points: 10, icon: '✅' },
  { id: 'r2', name: '回答问题', points: 5, icon: '🙋' },
  { id: 'r3', name: '优秀作业', points: 8, icon: '📝' },
  { id: 'r4', name: '帮助同学', points: 3, icon: '🤝' },
  { id: 'r5', name: '迟到', points: -5, icon: '⏰' },
  { id: 'r6', name: '扰乱课堂', points: -10, icon: '🔇' },
  { id: 'r7', name: '未完成作业', points: -5, icon: '📋' },
];

const INITIAL_SHOP: ShopItem[] = [
  { id: 'sh1', name: '免作业券', requiredPoints: 50, stock: 10, description: '免除一次课后作业', sold: 2 },
  { id: 'sh2', name: '座位自选权', requiredPoints: 30, stock: -1, description: '可自选心仪座位一次', sold: 5 },
  { id: 'sh3', name: '课堂加分卡', requiredPoints: 20, stock: 20, description: '下次测验额外加5分', sold: 3 },
  { id: 'sh4', name: '小零食兑换', requiredPoints: 15, stock: 30, description: '兑换小零食一份', sold: 8 },
];

const INITIAL_RECORDS: PointRecord[] = [
  { id: 'rc1', studentId: 's2', type: 'earn', points: 10, reason: '全勤', ruleId: 'r1', createdAt: '2024-11-01T09:00:00Z' },
  { id: 'rc2', studentId: 's6', type: 'earn', points: 5, reason: '回答问题', ruleId: 'r2', createdAt: '2024-11-02T09:30:00Z' },
  { id: 'rc3', studentId: 's1', type: 'deduct', points: 5, reason: '迟到', ruleId: 'r5', createdAt: '2024-11-02T10:00:00Z' },
  { id: 'rc4', studentId: 's8', type: 'earn', points: 8, reason: '优秀作业', ruleId: 'r3', createdAt: '2024-11-03T08:00:00Z' },
  { id: 'rc5', studentId: 's1', type: 'redeem', points: 20, reason: '兑换：课堂加分卡', shopItemId: 'sh3', createdAt: '2024-11-04T11:00:00Z' },
  { id: 'rc6', studentId: 's6', type: 'earn', points: 10, reason: '全勤', ruleId: 'r1', createdAt: '2024-11-05T09:00:00Z' },
  { id: 'rc7', studentId: 's10', type: 'earn', points: 8, reason: '优秀作业', ruleId: 'r3', createdAt: '2024-11-06T09:00:00Z' },
  { id: 'rc8', studentId: 's4', type: 'deduct', points: 5, reason: '未完成作业', ruleId: 'r7', createdAt: '2024-11-06T10:00:00Z' },
];

const STORAGE_KEY = 'class-mgmt-v1';

const loadState = (): AppState => {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) return JSON.parse(saved);
  } catch {}
  return {
    students: INITIAL_STUDENTS,
    groups: INITIAL_GROUPS,
    rules: INITIAL_RULES,
    records: INITIAL_RECORDS,
    shopItems: INITIAL_SHOP,
  };
};

interface AppContextType extends AppState {
  // Student ops
  addStudent: (name: string, groupId: string | null) => void;
  updateStudent: (id: string, name: string, groupId: string | null) => void;
  deleteStudent: (id: string) => void;
  importStudents: (names: string[], groupId: string | null) => number;
  // Group ops
  addGroup: (name: string, color: string) => void;
  updateGroup: (id: string, name: string, color: string) => void;
  deleteGroup: (id: string) => void;
  // Rule ops
  addRule: (name: string, points: number, icon: string) => void;
  updateRule: (id: string, name: string, points: number, icon: string) => void;
  deleteRule: (id: string) => void;
  // Point ops
  applyPoints: (studentIds: string[], points: number, reason: string, ruleId?: string) => void;
  redeemItem: (studentId: string, shopItemId: string) => { success: boolean; message: string };
  resetPoints: () => void;
  // Shop ops
  addShopItem: (name: string, requiredPoints: number, stock: number, description: string) => void;
  updateShopItem: (id: string, name: string, requiredPoints: number, stock: number, description: string) => void;
  deleteShopItem: (id: string) => void;
  // Helpers
  getStudentById: (id: string) => Student | undefined;
  getGroupById: (id: string) => Group | undefined;
  getGroupTotalPoints: (groupId: string) => number;
}

const AppContext = createContext<AppContextType | null>(null);

export const useApp = () => {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
};

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, setState] = useState<AppState>(loadState);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  }, [state]);

  const addStudent = (name: string, groupId: string | null) => {
    setState(s => ({ ...s, students: [...s.students, { id: uid(), name, groupId, totalPoints: 0, availablePoints: 0, createdAt: new Date().toISOString() }] }));
  };

  const updateStudent = (id: string, name: string, groupId: string | null) => {
    setState(s => ({ ...s, students: s.students.map(st => st.id === id ? { ...st, name, groupId } : st) }));
  };

  const deleteStudent = (id: string) => {
    setState(s => ({ ...s, students: s.students.filter(st => st.id !== id), records: s.records.filter(r => r.studentId !== id) }));
  };

  const importStudents = (names: string[], groupId: string | null): number => {
    const newStudents = names.map(name => ({ id: uid(), name: name.trim(), groupId, totalPoints: 0, availablePoints: 0, createdAt: new Date().toISOString() }));
    setState(s => ({ ...s, students: [...s.students, ...newStudents] }));
    return newStudents.length;
  };

  const addGroup = (name: string, color: string) => {
    setState(s => ({ ...s, groups: [...s.groups, { id: uid(), name, color }] }));
  };

  const updateGroup = (id: string, name: string, color: string) => {
    setState(s => ({ ...s, groups: s.groups.map(g => g.id === id ? { ...g, name, color } : g) }));
  };

  const deleteGroup = (id: string) => {
    setState(s => ({ ...s, groups: s.groups.filter(g => g.id !== id), students: s.students.map(st => st.groupId === id ? { ...st, groupId: null } : st) }));
  };

  const addRule = (name: string, points: number, icon: string) => {
    setState(s => ({ ...s, rules: [...s.rules, { id: uid(), name, points, icon }] }));
  };

  const updateRule = (id: string, name: string, points: number, icon: string) => {
    setState(s => ({ ...s, rules: s.rules.map(r => r.id === id ? { ...r, name, points, icon } : r) }));
  };

  const deleteRule = (id: string) => {
    setState(s => ({ ...s, rules: s.rules.filter(r => r.id !== id) }));
  };

  const applyPoints = (studentIds: string[], points: number, reason: string, ruleId?: string) => {
    const type: RecordType = points >= 0 ? 'earn' : 'deduct';
    const absPoints = Math.abs(points);
    const now = new Date().toISOString();
    const newRecords: PointRecord[] = studentIds.map(sid => ({ id: uid(), studentId: sid, type, points: absPoints, reason, ruleId, createdAt: now }));
    setState(s => ({
      ...s,
      students: s.students.map(st => {
        if (!studentIds.includes(st.id)) return st;
        const newAvailable = Math.max(0, st.availablePoints + points);
        const newTotal = type === 'earn' ? st.totalPoints + absPoints : st.totalPoints;
        return { ...st, totalPoints: newTotal, availablePoints: newAvailable };
      }),
      records: [...s.records, ...newRecords],
    }));
  };

  const redeemItem = (studentId: string, shopItemId: string): { success: boolean; message: string } => {
    const item = state.shopItems.find(i => i.id === shopItemId);
    const student = state.students.find(s => s.id === studentId);
    if (!item || !student) return { success: false, message: '数据错误' };
    if (item.stock !== -1 && item.stock - item.sold <= 0) return { success: false, message: '商品已售罄' };
    if (student.availablePoints < item.requiredPoints) return { success: false, message: `积分不足（需要 ${item.requiredPoints} 分，当前 ${student.availablePoints} 分）` };
    const record: PointRecord = { id: uid(), studentId, type: 'redeem', points: item.requiredPoints, reason: `兑换：${item.name}`, shopItemId, createdAt: new Date().toISOString() };
    setState(s => ({
      ...s,
      students: s.students.map(st => st.id === studentId ? { ...st, availablePoints: st.availablePoints - item.requiredPoints } : st),
      shopItems: s.shopItems.map(i => i.id === shopItemId ? { ...i, sold: i.sold + 1 } : i),
      records: [...s.records, record],
    }));
    return { success: true, message: '兑换成功！' };
  };

  const resetPoints = () => {
    setState(s => ({ ...s, students: s.students.map(st => ({ ...st, totalPoints: 0, availablePoints: 0 })), records: [] }));
  };

  const addShopItem = (name: string, requiredPoints: number, stock: number, description: string) => {
    setState(s => ({ ...s, shopItems: [...s.shopItems, { id: uid(), name, requiredPoints, stock, description, sold: 0 }] }));
  };

  const updateShopItem = (id: string, name: string, requiredPoints: number, stock: number, description: string) => {
    setState(s => ({ ...s, shopItems: s.shopItems.map(i => i.id === id ? { ...i, name, requiredPoints, stock, description } : i) }));
  };

  const deleteShopItem = (id: string) => {
    setState(s => ({ ...s, shopItems: s.shopItems.filter(i => i.id !== id) }));
  };

  const getStudentById = (id: string) => state.students.find(s => s.id === id);
  const getGroupById = (id: string) => state.groups.find(g => g.id === id);
  const getGroupTotalPoints = (groupId: string) => state.students.filter(s => s.groupId === groupId).reduce((sum, s) => sum + s.totalPoints, 0);

  return (
    <AppContext.Provider value={{
      ...state,
      addStudent, updateStudent, deleteStudent, importStudents,
      addGroup, updateGroup, deleteGroup,
      addRule, updateRule, deleteRule,
      applyPoints, redeemItem, resetPoints,
      addShopItem, updateShopItem, deleteShopItem,
      getStudentById, getGroupById, getGroupTotalPoints,
    }}>
      {children}
    </AppContext.Provider>
  );
};
