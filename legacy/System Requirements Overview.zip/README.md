
  # System Requirements Overview

  This is a code bundle for System Requirements Overview. The original project is available at https://www.figma.com/design/TIfXDLfCi3q0zN0O3YURFi/System-Requirements-Overview.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  